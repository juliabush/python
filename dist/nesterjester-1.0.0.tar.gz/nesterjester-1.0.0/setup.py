from setuptools import setup

setup(
    name="nesterjester",
    version="1.0.0",
    py_modules=["nester"],
    author="juliapython",
    author_email="j.elizabethbush@gmail.com",
    url="https://juliabush.dev",
    description="A simple recursive function for nested lists",
)
